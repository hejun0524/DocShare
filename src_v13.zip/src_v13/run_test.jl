using JuMP, Gurobi, UnitCommitment, JSON, DataStructures

import UnitCommitment: TimeDecomposition, ConventionalLMP

# make sure your terminal is not in the src folder, or do the following two lines
current_dir = "/Users/hejun/Documents/GitHub/research/unit_commitment/sample_test/src_v12"
cd(current_dir)

# Read benchmark instance
# for example, we want to read the 4th file: WEST2009-0101.json
input_fname = "GVNoIntLim.json"
instance = UnitCommitment.read(input_fname)

# you can replace it with optimizer = Gurobi.Optimizer to enable logging
optimizer = JuMP.optimizer_with_attributes(Gurobi.Optimizer, "OutputFlag" => 0)

# this is for lmps, it calculates the lmps for each sub-problem and append to the list
lmps = []
function compute_lmp_after_optimize(soution, model, instance) 
    lmp = UnitCommitment.compute_lmp(
        model,
        ConventionalLMP(),
        optimizer = optimizer,
    )
    push!(lmps, lmp)
end

# 1. use time decomposition to solve the large problem
solution = UnitCommitment.optimize!(
    instance,
    TimeDecomposition(
        time_window = 36,  # solve 36h problems
        time_increment = 24,  # advance by 24h each time
    ),
    optimizer = optimizer,
    after_optimize = compute_lmp_after_optimize
)

# post-process the LMPs
lmp_dict = OrderedDict()
for i in 1:length(lmps)
    lmp = lmps[i]
    # change this 24 to whatever was set as the time_increment in TimeDecomposition
    time_increment = 24
    # enumerate through the lmp dict, and correct the time stamp
    for (key, value) in lmp 
        gen_name = key[2]
        time_slot = key[3]
        if !haskey(lmp_dict, gen_name)
            lmp_dict[gen_name] = []
        end
        if time_slot <= time_increment
            append!(lmp_dict[gen_name], value)
        end
    end
end

# 2. write the solution
UnitCommitment.write("uc_outputs/GridViewSampleResult.json", solution)
UnitCommitment.write("uc_outputs/GridViewSampleResultLMP.json", lmp_dict)
