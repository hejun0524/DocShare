# get all the parameters
def get_params(excel_set, time_horizon=24):
    penalty_val = excel_set.query_and_retrieve(
        'SimulationControl',
        'Name',
        ['Area-Level Load Shedding Penalty'],
        'Value'
    )
    shedding_val = excel_set.query_and_retrieve(
        'SimulationControl',
        'Name',
        ['Load Shedding Penalty'],
        'Value'
    )
    params = {
        'Version': '0.4',
        'Time horizon (h)': time_horizon,
        'Power balance penalty ($/MW)': 3500.0,
        'Area-Level Load Shedding Penalty ($/MW; UNUSED)': float(penalty_val),
        'Load shed panealty ($/MW; UNUSED)': float(shedding_val)
    }
    return params


# get all the generators' information in a mega dictionary.
# can get all generators' based on the area name and month index.
# note that max powers of hourly resources need to be obtained separately.
def get_units(excel_set, shape_set):
    months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

    all_units = {}  # '<AREA_NAME>': gens...

    for _, gen_row in excel_set.get_excel('Generator').iterrows():
        service_stat = gen_row['ServiceStatus']
        if not service_stat:
            continue
        # for all in-service units
        gen_key = gen_row['GeneratorKey']
        bus_id = gen_row['BusID']
        gen_type_id = gen_row['GeneratorType']
        fuel_id = gen_row['FuelID']
        # query bus_df for area id & name
        area_id = excel_set.query_and_retrieve(
            'Bus', 'BusID', [bus_id], 'LoadAreaID'
        )
        area_name = excel_set.query_and_retrieve(
            'LoadArea', 'LoadAreaID', [area_id], 'LoadAreaName'
        )
        # key name
        if not all_units.get(area_name):
            all_units[area_name] = {}
        if gen_type_id == 1:
            # query iocurve for more cost curves
            curve_row = excel_set.query_df(
                'IOCurve', 'GeneratorKey', [gen_key])
            num_blocks = excel_set.retrieve_cell(curve_row, 'NumBlock')
            inc_caps = excel_set.retrieve_cell(
                curve_row, [f'IncCap{i}' for i in range(2, num_blocks+1)])
            inc_hrs = excel_set.retrieve_cell(
                curve_row, [f'IncHR{i}' for i in range(2, num_blocks+1)])
            min_mw = excel_set.retrieve_cell(curve_row, 'MinCap')
            min_input = excel_set.retrieve_cell(curve_row, 'MinInput')
            curve_mw_of_year = []
            curve_cost_of_year = []
            for k in range(12):
                mo_idx = k + 1
                days_of_mo = months[k]
                hrs_of_mo = days_of_mo * 24
                # query fuel schedule for monthly rate
                fuel_rate = excel_set.query_and_retrieve(
                    'FuelCostSchedule', 'FuelID', [fuel_id], f'V{mo_idx}'
                )
                cost_blocks = inc_caps * inc_hrs * fuel_rate
                min_cost = min_input * fuel_rate
                curve_mw = [min_mw] + list(inc_caps)
                curve_mw = [sum(curve_mw[0:i])
                            for i, v in enumerate(curve_mw, 1)]
                curve_cost = [min_cost] + list(cost_blocks)
                curve_cost = [sum(curve_cost[0:i])
                              for i, v in enumerate(curve_cost, 1)]
                # the same curve will repeat around 1200 times per month
                for _ in range(hrs_of_mo):
                    curve_mw_of_year.append(curve_mw)
                    curve_cost_of_year.append(curve_cost)
            # transpose this list of lists
            curve_mw_of_year = list(map(list, zip(*curve_mw_of_year)))
            curve_cost_of_year = list(map(list, zip(*curve_cost_of_year)))
            # construct the dict
            all_units[area_name].update({
                f'g{gen_key}': {
                    'Bus': area_name,
                    'Type': 'Thermal',
                    'Production cost curve (MW)': curve_mw_of_year,
                    'Production cost curve ($)': curve_cost_of_year,
                    'Ramp up limit (MW)': excel_set.retrieve_cell(curve_row, 'RampUpRate'),
                    'Ramp down limit (MW)': excel_set.retrieve_cell(curve_row, 'RampDnRate'),
                    'Startup limit (MW)': excel_set.retrieve_cell(curve_row, 'MinInput'),
                    'Shutdown limit (MW)': excel_set.retrieve_cell(curve_row, 'MinInput'),
                    'Minimum downtime (h)': gen_row['MinimumDownTime'],
                    'Minimum uptime (h)': gen_row['MinimumUpTime'],
                    'Initial status (h)': -100,
                    'Initial power (MW)': 0.0,
                    'Must run?': gen_row['MustRun'],
                    'Reserve type (UNUSED)': excel_set.retrieve_cell(curve_row, 'ReserveTypeProvided'),
                }
            })
        elif gen_type_id in [2, 4, 5]:
            # DAT-dependent
            mo_schedule_row = excel_set.query_df(
                'MonthlyVariableSchedule', 'DataTypeID', [1])
            mo_schedule_row = mo_schedule_row[mo_schedule_row['GeneratorKey'] == gen_key]
            specific_type = {
                2: 'Hydro',
                4: 'Hourly resources',
                5: 'CSP storage',
            }[gen_type_id]
            cost = []
            for k in range(12):
                mo_idx = k + 1
                days_of_mo = months[k]
                hrs_of_mo = days_of_mo * 24
                monthly_cost = excel_set.retrieve_cell(
                    mo_schedule_row, f'V{mo_idx}')
                cost.extend([monthly_cost] * hrs_of_mo)
            gen_data = {
                f'g{gen_key}': {
                    'Bus': area_name,
                    'Type': 'Profiled',
                    'Specific type (UNUSED)': specific_type,
                    'Cost ($/MW)': cost,
                    'Maximum power (MW)': 2000,  # will be fixed later
                }
            }

            shape_id = excel_set.query_and_retrieve(
                'HourlyResource', 'GeneratorKey', [
                    gen_key], 'CommitmentShapeID'
            )
            if shape_id:
                shape_file = excel_set.query_and_retrieve(
                    'Shape', 'ShapeID', [shape_id], 'ShapeFile'
                )
                commitment_multiplier = excel_set.query_and_retrieve(
                    'HourlyResource', 'GeneratorKey', [
                        gen_key], 'CommitmentMultiplier'
                )
                gen_data[f'g{gen_key}']['Commitment multiplier (UNUSED)'] = commitment_multiplier
                gen_data[f'g{gen_key}']['Shape file (UNUSED)'] = shape_file
                gen_data[f'g{gen_key}']['Maximum power (MW)'] = shape_set.get_data_on_date(
                    shape_file, multiplier=commitment_multiplier
                )
            else:
                # if not hourly resources (either hydro or storage)
                # retrieve PSSEMaxCap
                psse_max = excel_set.query_and_retrieve(
                    'Generator', 'GeneratorKey', [gen_key], 'PSSEMaxCap'
                )
                if psse_max:
                    gen_data[f'g{gen_key}']['Maximum power (MW)'] = float(
                        psse_max)
                if specific_type == 'Hydro':
                    # lmp info hard coded
                    gen_data[f'g{gen_key}']['Cost ($/MW)'] = 75
                    # get the HydroProfile.xlsx
                    max_power = excel_set.retrieve_col(
                        "HydroProfile", "Output (Normalized to 1,000 MW)"
                    )
                    # max_power = shape_set.get_data_on_date('hydro_shape.dat', date_str='ALL', multiplier=0.0001*psse_max)
                    if not (max_power is None):
                        gen_data[f'g{gen_key}']['Maximum power (MW)'] = (
                            max_power * psse_max / 1000).tolist()
                        gen_data[f'g{gen_key}']['PSSE max (UNUSED; MW)'] = float(
                            psse_max)

            all_units[area_name].update(gen_data)

    return all_units


# get all the interface's transmission information in a mega dictionary.
def get_interface_transmission(excel_set):
    all_lines = {}
    # enumerate through the InterfaceBranchesNew.xlsx
    for _, interface_row in excel_set.get_excel('InterfaceBranchesNew').iterrows():
        branch_id = interface_row['BranchID']
        interface_id = interface_row['InterfaceID']
        # query Branch to get the regular bus ID
        branch_info = excel_set.query_and_retrieve(
            'Branch', 'BranchID', [branch_id], ['FromBus', 'ToBus']
        )
        from_bus = branch_info[0]
        to_bus = branch_info[1]
        # query Bus & LoadArea to get the super bus ID then name
        from_area_id = excel_set.query_and_retrieve(
            'Bus', 'BusID', [from_bus], 'LoadAreaID'
        )
        to_area_id = excel_set.query_and_retrieve(
            'Bus', 'BusID', [to_bus], 'LoadAreaID'
        )
        from_area_name = excel_set.query_and_retrieve(
            'LoadArea', 'LoadAreaID', [from_area_id], 'LoadAreaName'
        )
        to_area_name = excel_set.query_and_retrieve(
            'LoadArea', 'LoadAreaID', [to_area_id], 'LoadAreaName'
        )
        # query InterfaceLimitHourly for the flow limit
        ### TO DO
        all_lines[f'l{branch_id}'] = {
            "Interface (UNUSED)": interface_id,
            "From bus (regular, UNUSED)": from_bus,
            "To bus (regular, UNUSED)": to_bus,
            "Source bus": from_area_name,
            "Target bus": to_area_name,
            "Reactance (ohms)": 0,
            "Susceptance (S)": 0,
            "Normal flow limit (MW)": 15000.0,
            "Emergency flow limit (MW)": 20000.0,
            "Flow limit penalty ($/MW)": 1e6,
        }
    
    return all_lines


# make sure all data has the post fix <year>
def modify_data_with_year(generators, year, area_name='MEGA'):
    for gen_dict in generators.values():
        gen_dict['Bus'] = f"{area_name}_{year}"
    all_keys = list(generators.keys())
    for gen_name in all_keys:
        generators[f'{gen_name}_{year}'] = generators.pop(gen_name)

def modify_transmission_data_with_year(lines, year):
    for line_dict in lines.values():
        line_dict['Source bus'] = f"{line_dict['Source bus']}_{year}"
    all_keys = list(lines.keys())
    for line_name in all_keys:
        lines[f'{line_name}_{year}'] = lines.pop(line_name)