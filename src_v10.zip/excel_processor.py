import pandas as pd
from file_validator import FileValidator

class ExcelSet:
    def __init__(self, fnames=[], dir='excel_files') -> None:
        if not fnames:
            fnames = [ 
                "Branch",
                "Bus",
                "FuelCostSchedule",
                "Generator",
                "HourlyResource",
                "Interface",
                "IOCurve",
                "LoadArea",
                "LoadAreaLoad",
                "MonthlyVariableSchedule",
                "MonthlyVariableScheduleType",
                "Shape",
                "SimulationControl",
                "InterfaceBranchesNew",
                "InterfaceLimitMonthly",
                "InterfaceLimitHourly",
                "HydroProfile",
            ]
        self.__dir = dir
        self.__fv = FileValidator([f'{fn}.xlsx' for fn in fnames], dir)
        self.__read_file()

    
    def __read_file(self):
        all_dfs = {}
        for fn in self.__fv.get_valid_files():
            df = pd.read_excel(f"./{self.__dir}/{fn}", keep_default_na=False)
            all_dfs[fn[:-5]] = df
        self.__fv.show_warning()
        self.__sets = all_dfs

    
    def get_excel(self, excel_name):
        return self.__sets[excel_name]

    
    def query_df(self, excel_name, query_key, query_vals):
        df = self.get_excel(excel_name)
        return df[df[query_key].isin(query_vals)]
    

    def retrieve_col(self, excel_name, lookup_cols):
        df = self.get_excel(excel_name)
        return df[lookup_cols].values


    def retrieve_cell(self, queried_rows, lookup_cols):
        values = queried_rows[lookup_cols].values
        if len(values):
            return values[0]
        return None
    

    def query_and_retrieve(self, excel_name, query_key, query_vals, lookup_cols):
        queried_rows = self.query_df(excel_name, query_key, query_vals)
        return self.retrieve_cell(queried_rows, lookup_cols)
    

    
