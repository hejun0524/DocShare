import re
from file_validator import FileValidator

class DatReader:
    def __init__(self, fname):
        f = open(fname)
        self.__lines = f.readlines()
        self.__header = self.__lines[0]
        self.__first_line = self.__lines[1]
        f.close()

        self.__parse_lines()

    def __identify_header(self):
        header_pattern = '\*\*, \d{4},'
        line_pattern_1 = '\d{7}\s+\d{60}'
        line_pattern_2 = '\d{7}\s+(\d{8}\.\d{3}){5}'
        start_pos = 0
        mode = -1
        if re.match(header_pattern, self.__header.strip()):
            start_pos = 1
        if re.match(line_pattern_1, self.__first_line.strip()):
            mode = 5
        if re.match(line_pattern_2, self.__first_line.strip()):
            mode = 12
        return start_pos, mode

    def __parse_lines(self):
        super_bus_dict = {}
        super_bus_arr = []
        start_pos, mode = self.__identify_header()
        for line in self.__lines[start_pos:]:
            if mode > 0:
                offset = mode
                # get time and loads
                time_str, load_str = line.strip().split()
                mmddyy = time_str[:-1]
                mmdd = mmddyy[:4]
                apm = int(time_str[-1])
                # init the super_bus_dict
                if not super_bus_dict.get(mmddyy):
                    super_bus_dict[mmddyy] = [0] * 24
                if not super_bus_dict.get(mmdd):
                    super_bus_dict[mmdd] = [0] * 24
                # get the hourly loads for this half day
                hourly_loads = [float(load_str[i:i+offset]) for i in range(0, len(load_str), offset)]
                super_bus_dict[mmddyy][12*(apm-1):12*apm] = hourly_loads
                super_bus_dict[mmdd][12*(apm-1):12*apm] = hourly_loads
                super_bus_arr.extend(hourly_loads)
        self.__data_dict = super_bus_dict
        self.__data_arr = super_bus_arr


    def retrieve_all_dates(self):
        return self.__data_dict 
    

    def retrieve_date(self, date_str='ALL', multiplier=1.0):
        if date_str == 'ALL':
            hourly_loads = self.__data_arr
        else:
            hourly_loads = self.__data_dict.get(date_str, [])
        return [x * multiplier for x in hourly_loads]


class DatSet:
    def __init__(self, fnames, dir='dat_files'):
        self.__dir = dir
        self.__fv = FileValidator(fnames, dir)
        self.__read_sets()

    def __read_sets(self):
        all_data = {}
        for fn in self.__fv.get_valid_files():
            all_data[fn] = DatReader(f'{self.__dir}/{fn}')
        self.__fv.show_warning()
        self.__sets = all_data
    
    def get_data_on_date(self, fname, date_str='ALL', multiplier=1.0):
        dat_data = self.__sets.get(fname)
        if dat_data is None:
            print(f'@error: file {fname} does not exist.')
            return None
        return dat_data.retrieve_date(date_str, multiplier)