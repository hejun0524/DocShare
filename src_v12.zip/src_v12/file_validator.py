from pathlib import Path

# given a list of file names and their directory
# this class checks if each file exists and is indeed a file
# it splits the files into 2 arrays
class FileValidator():
    def __init__(self, fnames, dir):
        self.__fnames = fnames
        self.__dir = dir
        self.__valid_files = []
        self.__invalid_files = []
        self.__validate_files()

    def __validate_files(self):
        for fn in self.__fnames:
            my_file = Path(f'{self.__dir}/{fn}')
            if my_file.is_file():
                self.__valid_files.append(fn)
            else:
                self.__invalid_files.append(fn)
    
    def get_valid_files(self):
        return self.__valid_files
    
    def get_invalid_files(self):
        return self.__invalid_files
    
    def show_warning(self):
        for fn in self.__invalid_files:
            print(f'@warning: file {fn} does not exist, it is not loaded.')